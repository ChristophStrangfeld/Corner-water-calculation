function [ pore_saturation_hexagon_pore_BET_sorption_plus_corner_water, hexagonal_pore_relative_share_corner_water ] = saturation_of_hexagon_pore_BET_sorption_plus_coner_water( height, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore height of a regular hexagon pore and relative humidity
%   determine the saturation of a hexagon pore depending on the relative humidity based on BET and Kelvin equation

%%%%%%% define the need constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% area of the dry hexagon pore
a_hexagon = 2*sqrt(3)*(height/2)^2;

% area of the pore occupied by the adsorbed water film
a_BET = a_hexagon - 2*sqrt(3)*(height/2 - t_a)^2;

% opening angle of the circle segment in radian
alpha = 60*pi/180;

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment = r_Kelvin^2/2*(alpha-sin(alpha));

% calcualte chord of the circle segment
chord = 2*r_Kelvin*sin(alpha/2);

% opening angle of the circle segment in radian
gamma = 120*pi/180;

% area of the equilateral triangular which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle = chord^2/4*cot(gamma/2);

% corner area formed by the two edge of the pore and the circle cutting this edge with the Kelvin radius 
a_corner = a_corner_triangle - a_circle_segment;

% relative pore area filled due to BET sorption
area_BET = a_BET/a_hexagon;

% relative pore area filled due to corner water
area_cornerwater = 6*a_corner / a_hexagon;

if 2*t_a  < height && abs(r_Kelvin)  < height/2 - t_a
    pore_saturation_hexagon_pore_BET_sorption_plus_corner_water = area_BET + area_cornerwater; %%%%%%% saturation of the hexagon pore based on adsorbed water layer at each surface calculated with BET sorption theory and corner water calculated with Kelvin equation
    % normalised relative share of corner water of the current combined saturation
    hexagonal_pore_relative_share_corner_water = area_cornerwater / (area_BET + area_cornerwater);
else
    pore_saturation_hexagon_pore_BET_sorption_plus_corner_water = 1;
    % normalised relative share of corner water of the current combined saturation
    hexagonal_pore_relative_share_corner_water = NaN;
end

end
