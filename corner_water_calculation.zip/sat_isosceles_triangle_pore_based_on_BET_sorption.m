function [ pore_sat_isosceles_triangle_pore_based_on_BET_sorption] = sat_isosceles_triangle_pore_based_on_BET_sorption( height, humidity, kappa, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore hight of an equilateral triangular pore and relative humidity
%   determine the saturation of an equilateral triangular pore depending on the relative humidity based on the Kelvin equation

%%%%%%% define the need constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory

% angle of the two blunt edges of the isosceles triangle
lambda = (pi-kappa)/2;

% area of an equilateral triangle with the given height
area_equilateral = 1/sqrt(3)*height^2;

% base of an isosceles triangle with an area corresponding to area_equilateral
base_isosceles = sqrt(4*area_equilateral/(cot(kappa/2)));

% side of an isosceles triangle with an area corresponding to area_equilateral
side_isosceles = base_isosceles/(2*sin(kappa/2));

% edge length along side perpendicular to delta_h, i.e. upper part
e2_iso = t_a/tan(kappa/2);

% edge length along side perpendicular to t_a, i.e. lower part
e1_iso = t_a/tan(lambda/2);

% part of base which is covered by t_a without an angle, along this distance t_a is constant
base_star_iso = base_isosceles - 2*e1_iso;

% part of base which is covered by t_a without an angle, along this distance t_a is constant
side_star_iso = side_isosceles - e1_iso - e2_iso;

% height of the isosceles triangle orthgonal to the base
height_on_base_isosceles = 0.5*sqrt(4*side_isosceles^2-base_isosceles^2);

if t_a+e2_iso/cos(kappa/2)  < height_on_base_isosceles
    pore_sat_isosceles_triangle_pore_based_on_BET_sorption = (2*t_a*(side_star_iso+e1_iso)+t_a*base_star_iso+t_a*e2_iso) / area_equilateral; %%%%%%% saturation of the triangular pore based on the corner water determined by the Kelvin equation
else
    pore_sat_isosceles_triangle_pore_based_on_BET_sorption = 1;
end

end
