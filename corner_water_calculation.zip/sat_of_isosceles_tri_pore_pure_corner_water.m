function [ pore_sat_isosceles_tri_pore_pure_corner_water ] = sat_of_isosceles_tri_pore_pure_corner_water( height, humidity, kappa, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore hight of an equilateral triangular pore and relative humidity
%   determine the saturation of an equilateral triangular pore depending on the relative humidity based on the Kelvin equation

% angle of the two blunt edges of the isosceles triangle
lambda = (pi-kappa)/2;

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% area of an equilateral triangle with the given height
area_equilateral = 1/sqrt(3)*height^2;

% base of an isosceles triangle with an area corresponding to area_equilateral
base_isosceles = sqrt(4*area_equilateral/(cot(kappa/2)));

% side of an isosceles triangle with an area corresponding to area_equilateral
side_isosceles = base_isosceles/(2*sin(kappa/2));

% height of the isosceles triangle orthgonal to the base
height_on_base_isosceles = 0.5*sqrt(4*side_isosceles^2-base_isosceles^2);

% inner radius of the isosceles triangle
r_inside = base_isosceles*height_on_base_isosceles / (2*side_isosceles+base_isosceles);

% calcualte chord of the circle segment of the spiky angle
chord_spiky_angle = 2*abs(r_Kelvin)*sin((pi-kappa)/2);

% calcualte chord of the circle segment of the blunt angle
chord_blunt_angle = 2*abs(r_Kelvin)*sin((pi-lambda)/2);

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment_spiky_angle = abs(r_Kelvin)^2/2*(pi-kappa-sin(pi-kappa));

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment_blunt_angle = abs(r_Kelvin)^2/2*(pi-lambda-sin(pi-lambda));

% area of the triangular of the spiky angle which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle_spiky_corner = chord_spiky_angle^2/4*cot(kappa/2);

% area of the triangular of the blunt angle which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle_blunt_corner = chord_blunt_angle^2/4*cot(lambda/2);

% corner area formed by the two edge of the pore and the circle cutting this edge with the Kelvin radius 
a_corner = a_corner_triangle_spiky_corner - a_circle_segment_spiky_angle + 2*(a_corner_triangle_blunt_corner-a_circle_segment_blunt_angle);

if abs(r_Kelvin)  < r_inside
    pore_sat_isosceles_tri_pore_pure_corner_water = a_corner/area_equilateral; %%%%%%% saturation of the triangular pore based on the corner water determined by the Kelvin equation
else
    pore_sat_isosceles_tri_pore_pure_corner_water = 1;
end

end
