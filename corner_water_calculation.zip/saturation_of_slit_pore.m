function [ pore_saturation_slit_pore,air_bubble_distance_slit_pore_in_m ] = saturation_of_slit_pore( distance, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given distance between pore walls for cement based screed depending of the relative humidity
%   determine the saturation of a SLIT pore depending on the relative humidity based on theory of Brunauer, Emmett and Teller 1938 in the formulation of Hillerborg 1985 (considering a SLIT pore) 


%%%%%%% define the need constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory 

pore_saturation_slit_pore = 2*t_a/distance; %%%%%%% saturation of the SLIT pore

pore_saturation_slit_pore((pore_saturation_slit_pore>1))=1;%%%%%% if the pore saturation is >1, we set it to 1, which means 100% saturation, the pore is completely filled

air_bubble_distance_slit_pore_in_m = distance-2*t_a;

if air_bubble_distance_slit_pore_in_m<0
    air_bubble_distance_slit_pore_in_m = 0 ;
end


end
