function [ pore_saturation_hexagon_pore_pure_corner_water ] = saturation_of_hexagon_pore_pure_corner_water( height, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore hight of a hexagon pore and relative humidity
%   determine the saturation of a hexagonal pore depending on the relative humidity based on the Kelvin equation

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% area of the dry hexagon pore
a_hexagon = 2*sqrt(3)*(height/2)^2;

% opening angle of the circle segment in radian
alpha = 60*pi/180;

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment = r_Kelvin^2/2*(alpha-sin(alpha));

% opening angle of the circle segment in radian
gamma = 120*pi/180;

% area of the isosceles triangular which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle = r_Kelvin^2/4*cot(gamma/2);

% corner area formed by the two edge of the pore and the circle cutting this edge with the Kelvin radius 
a_corner = a_corner_triangle - a_circle_segment;

if 2*abs(r_Kelvin)  < height
    pore_saturation_hexagon_pore_pure_corner_water = 6*a_corner/a_hexagon; %%%%%%% saturation of the hexagonal pore based on the corner water determined by the Kelvin equation
else
    pore_saturation_hexagon_pore_pure_corner_water = 1;
end

end
