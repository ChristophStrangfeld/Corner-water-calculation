function [ pore_saturation_triangular_pore_based_on_BET_sorption ] = saturation_of_triangluar_pore_based_on_BET_sorption( height, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore height of an equilateral triangular pore and relative humidity
%   determine the saturation of an equilateral triangular pore depending on the relative humidity based on theory of Brunauer, Emmett and Teller 1938 in the formulation of Hillerborg 1985 (considering a SLIT pore)

%%%%%%% define the need constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory

a = 2/sqrt(3)*height; %%%%% a is the uniform edge length of the equilateral triangular

e = sqrt(3)* t_a; %%%%% e is the distance from the triangualr corner tip along the edge depending on t_a

if 3*t_a  < height
    pore_saturation_triangular_pore_based_on_BET_sorption = 4*sqrt(3)*(t_a*a - t_a*e)/(a^2); %%%%%%% saturation of the triangular pore based on adsorbed water layer at each surface calculated with BET sorption theory
else
    pore_saturation_triangular_pore_based_on_BET_sorption = 1;
end

end
