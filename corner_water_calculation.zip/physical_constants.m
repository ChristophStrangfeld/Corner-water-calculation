function [data] = physical_constants(data)
%PHYSICAL_CONSTANTS Summary of this function goes here
%   Detailed explanation goes here

% ambient temperuatre (T) in K (corresponds to +23� C)
data.total_temperatur = 296.15; 

% ambient air pressure (p) in Pa
data.ambient_air_pressure = 101325; 

% water density in kg/m^3 for T = 296.15 K and p = 101325 Pa
data.liquid_water_density = 997.54; 

% thickness of a monolayer of physisorbed water in m
data.waterlayer_thickness = 0.35*10^-9;

% proportionality factor C required for BET sorption theory (equation 1, Brunauer 1938) and Hillerborg sorption theory (equation 1 in Hillerborg 1985)
% numerical value from Xi_1994 according to Chaub_199, Ishida_2007 
% C is an exportential funciton of the heat of adsorption of the first physisorbed layer and heat of adsorption of the second or higher physisorbed layer (equation 5, Xi 1994)
data.BET_proportionality_constant = 15; %%%%%

% R in J/(mol*K) or N*m/(mol*K)
data.ideal_gas_constant = 8.314;

% M in kg/mol for water
data.molecular_mass_water = 0.0180153;

% gamma in N/m surface tension of liquid water at T =23� C and p = 101325 Pa
data.surface_tension = 72232*10^-6;


% 
% data.monolayer_moisture_content = 0.045;%%%% v_m, monolayer capacity/ monolayer moisture content for screed v_m, value from figure 2, day 90, Xi_1994
% 
% 
% 
% 
% 
% 
% 

% 
% 
% 
% data.dynamic_viscosity = 18.3809*10^-6; %%%%% eta in Pa*s, viscosity for T =23� C, p =101325 Pa, value online from peace software database
% 
% data.air_density = 1.192208; %%%%%% rho_l in kg/m^3, T =23� C, p =101325 Pa, value online from peace software database
% 
% data.constant_free_path_length_jennings = 0.4987445; %%%%% u, numerical factor from Jennings_1988
% 
% data.vapor_diffusivity_in_free_air = 26.715*10^-6;%%%%%% D_0 in m^2/s vapor diffusivity in free atmosphere, Richter_2008
% 
% data.water_vapour_pressure_at_saturation = 2815.7; %%%%%% in Pa for T=23�C and p=101325 Pa
% 
% %%%%%%% absolut vapour density at saturation at T=23�C and p=101325 Pa
% data.absolut_vapour_density_at_saturation = data.water_vapour_pressure_at_saturation*data.molecular_mass_water/(data.ideal_gas_constant*data.total_temperatur);%%%%% in kg/m^3
% 
% %%%%%% calculate the mean free path, in this case it is 66.448 nm
% data.free_path_length = (pi/8)^0.5 *data.dynamic_viscosity/data.constant_free_path_length_jennings * 1/(data.air_density*data.ambient_air_pressure)^0.5; %%%% l_m in nm; T=23� C, p = 101325 Pa; Jennings_1988; in table 5, l_m ist given with 66.38 nm


end























