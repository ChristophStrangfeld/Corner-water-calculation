function [ pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water,isosceles_tri_pore_relative_share_corner_water] = sat_isosceles_triangle_pore__BET_sorption_plus_corner_water( height, humidity, kappa, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore hight of an equilateral triangular pore and relative humidity
%   determine the saturation of an equilateral triangular pore depending on the relative humidity based on the Kelvin equation

%%%%%%% define the need constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% angle of the two blunt edges of the isosceles triangle
lambda = (pi-kappa)/2;

% area of an equilateral triangle with the given height
area_equilateral = 1/sqrt(3)*height^2;

% base of an isosceles triangle with an area corresponding to area_equilateral
base_isosceles = sqrt(4*area_equilateral/(cot(kappa/2)));

% side of an isosceles triangle with an area corresponding to area_equilateral
side_isosceles = base_isosceles/(2*sin(kappa/2));

% edge length along side perpendicular to delta_h, i.e. upper part
e2_iso = t_a/tan(kappa/2);

% edge length along side perpendicular to t_a, i.e. lower part
e1_iso = t_a/tan(lambda/2);

% part of base which is covered by t_a without an angle, along this distance t_a is constant
base_star_iso = base_isosceles - 2*e1_iso;

% part of base which is covered by t_a without an angle, along this distance t_a is constant
side_star_iso = side_isosceles - e1_iso - e2_iso;

% height of the isosceles triangle orthgonal to the base
height_on_base_isosceles = 0.5*sqrt(4*side_isosceles^2-base_isosceles^2);

% height of the isosceles triangle which is reduced in cross section due to physisorbed water
height_star = height_on_base_isosceles - t_a - e2_iso/cos(kappa/2);

% inner radius of the isosceles triangle which is reduced in cross section due to physisorbed water
r_inside_wet = base_star_iso*height_star / (2*side_star_iso+base_star_iso);

% calcualte chord of the circle segment of the spiky angle
chord_spiky_angle = 2*abs(r_Kelvin)*sin((pi-kappa)/2);

% calcualte chord of the circle segment of the blunt angle
chord_blunt_angle = 2*abs(r_Kelvin)*sin((pi-lambda)/2);

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment_spiky_angle = abs(r_Kelvin)^2/2*(pi-kappa-sin(pi-kappa));

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment_blunt_angle = abs(r_Kelvin)^2/2*(pi-lambda-sin(pi-lambda));

% area of the triangular of the spiky angle which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle_spiky_corner = chord_spiky_angle^2/4*cot(kappa/2);

% area of the triangular of the blunt angle which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle_blunt_corner = chord_blunt_angle^2/4*cot(lambda/2);

% corner area formed by the two edge of the pore and the circle cutting this edge with the Kelvin radius 
area_cornerwater = a_corner_triangle_spiky_corner - a_circle_segment_spiky_angle + 2*(a_corner_triangle_blunt_corner-a_circle_segment_blunt_angle);

% relative pore area filled due to BET sorption
area_BET = 2*t_a*(side_star_iso+e1_iso)+t_a*base_star_iso+t_a*e2_iso;

if t_a+e2_iso/cos(kappa/2)  < height_on_base_isosceles && abs(r_Kelvin)  < r_inside_wet

    pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water = (area_BET + area_cornerwater) / area_equilateral; %%%%%%% saturation of the triangular pore based on the corner water determined by the Kelvin equation
    % normalised relative share of corner water of the current combined saturation
    isosceles_tri_pore_relative_share_corner_water = area_cornerwater / (area_BET + area_cornerwater);
else
    pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water = 1;
    % normalised relative share of corner water of the current combined saturation
    isosceles_tri_pore_relative_share_corner_water = NaN;
end

end
