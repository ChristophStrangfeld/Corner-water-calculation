function [ pore_saturation_quadratic_pore_BET_sorption_plus_corner_water, square_pore_relative_share_corner_water ] = saturation_of_quadratic_pore_BET_sorption_plus_corner_water( edge_length, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore height of a quadratic pore and relative humidity
%   determine the saturation of a quadratic pore depending on the relative humidity based on BET theory and corner water

%%%%%%% define the needed constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% relative pore area filled due to BET sorption
area_BET = 4*(edge_length - t_a)*t_a /(edge_length^2);

% relative pore area filled due to corner water
area_cornerwater = r_Kelvin^2*(4-pi)/(edge_length^2);

% calculate the pore saturation
if 2*abs(r_Kelvin)  < edge_length-2*t_a
    pore_saturation_quadratic_pore_BET_sorption_plus_corner_water = area_BET + area_cornerwater ; %%%%%%% saturation of the quadratic pore based on adsorbed water layer at each surface calculated with BET sorption theory
    % normalised relative share of corner water of the current combined saturation
    square_pore_relative_share_corner_water = area_cornerwater / (area_BET + area_cornerwater);
else
    pore_saturation_quadratic_pore_BET_sorption_plus_corner_water = 1;
    % normalised relative share of corner water of the current combined saturation
    square_pore_relative_share_corner_water = NaN;
end

end
