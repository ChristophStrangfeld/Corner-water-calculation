function [ pore_saturation_cylindircal_pore, air_bubble_radius_cylindircal_pore ] = saturation_of_cylindrical_pore( diameter, humidity, data )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given radius for cement based screed depending of the relative humidity
%   determine the saturation of a CYLINDRIC pore depending on the relative humidity based on theory of Hillerborg 1985, Chaube 1994, Ishida 1997, Ishida 2007

radius = diameter/2;

%%%%%%% define the need constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_3 = data.surface_tension*data.molecular_mass_water/data.liquid_water_density/data.ideal_gas_constant/data.total_temperatur;%%%%%% third constant

t_init = 10^-12;%%%%%%%% in nm, initial layer thickness for the interation
accuracy = 10^-15;%%%%%%% required accuary for the iteration
max_iter=10000;%%%%%%% maximum iteration steps

%%%%%% initial parameters for the iteration
t_a = t_init;%%%% initial layer thicknes
iteration_step = 0;%%%% iteration counter
stop=0;%%%%% to stop the loop if a solution is found
t_a_final = NaN;%%%%% if we do not find an apropriate solution, the layer thickness remains undetermined and the saturation becomes 1

%%%%%% start the fix point iteration
while iteration_step < max_iter && stop<1
    iteration_step=iteration_step+1;
    
    t_alt = t_a;%%%%% layer thickness of the last iteration to check the deviation/accuracy of our solution
    
    if t_a<radius%%%%% physical condition, the layer thickness must be beloew the pore radius
        
        h_m = exp( -c_3/(radius-t_a) );%%%% Ishida 2007, equation 13
        
        t_a = c_1*humidity/ ( (1-humidity/h_m)*(1-humidity/h_m+data.BET_proportionality_constant*humidity) );%%%% Ishida 2007, equation 12
        
        deviation = abs(t_a-t_alt);%%%%% to check convergence of our iteration
        
        if t_a>0 && deviation<accuracy%%%%% only if the layer thickness is positive and the deviation is below our required accuracy, the determined layre thickness is considered to be valid
            t_a_final = t_a;%%%%% final layer thickness, else it remains as NaN
            stop =1;%%%%% stop the iteration right now
        end
        
    end
    
end

pore_saturation_cylindircal_pore = 1-((radius - t_a_final) / radius)^2;%%%%%%% saturation of the CYLINDRIC pore

pore_saturation_cylindircal_pore(isnan(pore_saturation_cylindircal_pore)) = 1;%%%%%% if the pore saturation is NaN, we set it to 1, which means 100% saturation, the pore is completely filled

air_bubble_radius_cylindircal_pore = radius - t_a_final;%%%%%%% the radius of the air bubble in the middle of the cylindric pore, this is important for the duffision coefficient especially if the air bubble is smaller than the mean free path

air_bubble_radius_cylindircal_pore(isnan(air_bubble_radius_cylindircal_pore)) = 0;%%%%%% if the air bubble raidus is NaN, we set it to 0 because the pore is fully saturated and no air bubble exists

end






































