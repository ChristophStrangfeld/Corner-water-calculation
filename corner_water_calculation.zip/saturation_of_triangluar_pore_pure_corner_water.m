function [ pore_saturation_triangular_pore_pure_corner_water ] = saturation_of_triangluar_pore_pure_corner_water( height, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore hight of an equilateral triangular pore and relative humidity
%   determine the saturation of an equilateral triangular pore depending on the relative humidity based on the Kelvin equation

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% area of the dry triangular pore
a_triangular = 1/sqrt(3)*height^2;

% inner radius of the dry triangular pore
r_inside = height/3;

% opening angle of the circle segment in radian
alpha = 120*pi/180;

% calcualte chord of the circle segment
chord = 2*r_Kelvin*sin(alpha/2);

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment = r_Kelvin^2/2*(alpha-sin(alpha));

% area of the equilateral triangular which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle = sqrt(3)/4*chord^2;

% corner area formed by the two edge of the pore and the circle cutting this edge with the Kelvin radius 
a_corner = a_corner_triangle - a_circle_segment;

if abs(r_Kelvin)  < r_inside
    pore_saturation_triangular_pore_pure_corner_water = 3*a_corner/a_triangular; %%%%%%% saturation of the triangular pore based on the corner water determined by the Kelvin equation
else
    pore_saturation_triangular_pore_pure_corner_water = 1;
end

end
