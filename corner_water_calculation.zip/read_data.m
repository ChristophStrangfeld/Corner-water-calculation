function [data] = read_data
% read the pore volume distribution and the available sorption isotherms from the txt file located in the folder 01_data
% all data are stored in a struct and ordered with field names material_"productname"
% pore volume distributions are available for all materials
% sorption isotherms are only available for the clay based materials and for most sandstone materials
% there are no sorption isotherms available for the screed materials, as they never reached stead-state conditions during drying


% find all txt files which contain the pore volume distribtuion of the materials
all_material_files = dir('..\01_data\pore_volume_distribution*.txt');

% find all txt files which contain the pore volume distribtuion of the materials
all_moisture_files = dir('..\01_data\sorption_isotherm*.txt');

% read the pore volume distributions which are the material data
for index_material = 1:length(all_material_files)

    % read the material name from the txt file
    material_name = "material_" + string(extractBetween(all_material_files(index_material,1).name, 'pore_volume_distribution_','.txt'));

    % save teh material name which is identical with the varaible name in the data-struct
    data.(material_name).material_name = material_name;
   
    % Set up the Import Options and import the data
    opts = delimitedTextImportOptions("NumVariables", 3);

    % Specify range and delimiter
    opts.DataLines = [2, Inf];
    opts.Delimiter = "\t";

    % Specify column names and types
    opts.VariableNames = ["pore_diameter_in_m", "cumulated_pore_volume_in_mm3", "incremental_pore_volume_in_mm3"];
    opts.VariableTypes = ["double", "double", "double"];

    % Specify file level properties
    opts.ExtraColumnsRule = "ignore";
    opts.EmptyLineRule = "read";

    % Import the data
    tbl = readtable(['..\01_data\',all_material_files(index_material,1).name], opts);

    % Convert to output type
    data.(material_name).pore_diameter_in_m = tbl.pore_diameter_in_m;
    data.(material_name).cumulated_pore_volume_in_mm3 = tbl.cumulated_pore_volume_in_mm3;
    data.(material_name).incremental_pore_volume_in_mm3 = tbl.incremental_pore_volume_in_mm3;
end

% read the sorption isotherms which are the moisture data
for index_material = 1:length(all_moisture_files)

    % read the material name from the txt file
    material_name = "material_" + string(extractBetween(all_moisture_files(index_material,1).name, 'sorption_isotherm_','.txt'));

    % Set up the Import Options and import the data
    opts = delimitedTextImportOptions("NumVariables", 2);

    % Specify range and delimiter
    opts.DataLines = [2, Inf];
    opts.Delimiter = "\t";

    % Specify column names and types
    opts.VariableNames = ["moisutre_in_mass_percent", "humidity"];
    opts.VariableTypes = ["double", "double"];

    % Specify file level properties
    opts.ExtraColumnsRule = "ignore";
    opts.EmptyLineRule = "read";

    % Import the data
    tbl = readtable(['..\01_data\',all_moisture_files(index_material,1).name], opts);

    % Convert to output type
    data.(material_name).moisutre_in_mass_percent = tbl.moisutre_in_mass_percent;
    data.(material_name).humidity = tbl.humidity;
end


