function [ pore_saturation_triangular_pore_BET_sorption_plus_corner_water, triangular_pore_relative_share_corner_water ] = saturation_of_triangluar_pore_BET_sorption_plus_corner_water( height, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore height of an equilateral triangular pore and relative humidity
%   determine the saturation of an equilateral triangular pore depending on the relative humidity based on BET theory and corner water

%%%%%%% define the needed constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory

a = 2/sqrt(3)*height; %%%%% a is the uniform edge length of the equilateral triangular

e = sqrt(3)* t_a; %%%%% e is the distance from the triangualr corner tip along the edge depending on t_a

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% area of the dry triangular pore
a_triangular = 1/sqrt(3)*height^2;

% opening angle of the circle segment in radian
alpha = 120*pi/180;

% calcualte chord of the circle segment
chord = 2*abs(r_Kelvin)*sin(alpha/2);

% height of the wet triangular pore with is the dry pore triangle reduced by the adsorbed water layer based on BET
height_wet = sqrt(3)/2*(a - 2*sqrt(3)*t_a);

% inner radius of the wet triangular pore with is the dry pore triangle reduced by the adsorbed water layer based on BET
r_inside_wet = height_wet/3;

% area of the circle segment cutted by the chord which connects the two tangents/ pore walls at the Kelvin radius
a_circle_segment = abs(r_Kelvin)^2/2*(alpha-sin(alpha));

% area of the equilateral triangular which is formed by the chord and the two edges of the corner of the pore
a_corner_triangle = sqrt(3)/4*chord^2;

% corner area formed by the two edge of the pore and the circle cutting this edge with the Kelvin radius 
a_corner = a_corner_triangle - a_circle_segment;

% relative pore area filled due to BET sorption
area_BET = 3*(t_a*(a-2*e)+e*t_a)/a_triangular;

% relative pore area filled due to corner water
area_cornerwater = 3*a_corner/a_triangular;

if 3*t_a  < height && abs(r_Kelvin)  < r_inside_wet
    pore_saturation_triangular_pore_BET_sorption_plus_corner_water = area_BET+area_cornerwater ; %%%%%%% saturation of the triangular pore based on adsorbed water layer at each surface calculated with BET sorption theory
    % normalised relative share of corner water of the current combined saturation
    triangular_pore_relative_share_corner_water = area_cornerwater / (area_BET + area_cornerwater);
else
    pore_saturation_triangular_pore_BET_sorption_plus_corner_water = 1;
    % normalised relative share of corner water of the current combined saturation
    triangular_pore_relative_share_corner_water = NaN;
end

end
