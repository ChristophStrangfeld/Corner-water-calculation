function [ pore_saturation_quadratic_pore_pure_corner_water ] = saturation_of_quadratic_pore_pure_corner_water( edge_length, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore hight of a quadratic pore and relative humidity
%   determine the saturation of a quadratic pore depending on the relative humidity based on the Kelvin equation

% calculate the critical Kelvin radius with the Kelvin equation, for convex formed water-air interfaces, the radius becomes negative which is in accordance to theory
r_Kelvin = 2*data.surface_tension*data.molecular_mass_water/(log(humidity)*data.ideal_gas_constant*data.total_temperatur*data.liquid_water_density);

% calculate the pore saturation
if 2*abs(r_Kelvin)  < edge_length
    pore_saturation_quadratic_pore_pure_corner_water = (r_Kelvin^2*(4-pi)) /(edge_length^2); %%%%%%% saturation of the quadratic pore based on corner water in each of the four corners determined by the Kelvin equation
else
    pore_saturation_quadratic_pore_pure_corner_water = 1;
end

end
