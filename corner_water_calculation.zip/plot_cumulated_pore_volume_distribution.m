function plot_cumulated_pore_volume_distribution(data, material_list)
% read the pore volume distribution and the available sorption isotherms from the txt file located in the folder 01_data
% all data are stored in a struct and ordered with field names material_"productname"
% pore volume distributions are available for all materials
% sorption isotherms are only available for the clay based materials and for most sandstone materials
% there are no sorption isotherms available for the screed materials, as they never reached stead-state conditions during drying


figure(1)
for material_index = 1:length(material_list)

    % plot the cumulated pore volume distribution over the pore radii, the summation start at largest radius and cumulates towards the lower radius
    plot(data.(material_list{material_index}).pore_diameter_in_m, data.(material_list{material_index}).cumulated_pore_volume_in_mm3)

    % logartihmic scale of the pore radii
    set(gca, 'XScale', 'log')

    % plot all pore volume distributions in one plot as general overview
    hold on
end

% limits for the pore radii
xlim([1e-9 1e-3])

xlabel('pore radius in m')
ylabel('cumulated pore volume distribution in mm^3g^{-1}')

legend(material_list, 'Location', 'eastoutside','Interpreter', 'none')