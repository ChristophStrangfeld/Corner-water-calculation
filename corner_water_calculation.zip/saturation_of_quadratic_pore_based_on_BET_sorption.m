function [ pore_saturation_quadratic_pore_based_on_BET_sorption ] = saturation_of_quadratic_pore_based_on_BET_sorption( edge_length, humidity, data  )
%PORE_SATURATION calculates the saturation of a pore with liquid water at a given pore height of a quadratic pore and relative humidity
%   determine the saturation of a quadratic pore depending on the relative humidity based on theory of Brunauer, Emmett and Teller 1938 in the formulation of Hillerborg 1985 (considering a SLIT pore)

%%%%%%% define the need constants
c_1 = data.BET_proportionality_constant * data.waterlayer_thickness;%%%%% in nm, one-molar layer thickness 0.35nm times cement constant of 15
c_2 = data.BET_proportionality_constant;%%%%%% individual constant for cement based screed

t_a = c_1*humidity/ ( (1-humidity)*(1-humidity+c_2*humidity) );%%%% Hilleborg 1985, equation 18 with phi_m = 1 which is equivalent with BET sorption theory

if 2*t_a  < edge_length
    pore_saturation_quadratic_pore_based_on_BET_sorption = 4*t_a*(edge_length-t_a) /(edge_length^2); %%%%%%% saturation of the triangular pore based on adsorbed water layer at each surface calculated with BET sorption theory
else
    pore_saturation_quadratic_pore_based_on_BET_sorption = 1;
end

end
