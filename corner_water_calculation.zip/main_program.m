clear all
close all
clc

% read the pore volume distribution and the available sorption isotherms from the txt file located in the folder 01_data
% all data are stored in a struct and ordered with field names material_"productname"
[data] = read_data;

% get a list of investigated materials
material_list = fieldnames(data);

% read defined physical constants
[data] = physical_constants(data);

% plot the cumulated pore volume distribution for all materials to control data consistency
plot_cumulated_pore_volume_distribution(data, material_list);

%% compute sorption isotherm for a single pore
%% cylindircal pore with Hillerborg sorption theory

% humidity levels in the unit of relative humidity
data.humidity_levels = 0.001:0.001:0.99;

% pore radii in m of the cylidnrical pores
data.cylindrical_pore_diameter = [1,2,3,5,10,20,50,100,200]*1e-9;

disp('compute sorption isotherm of single cylindrical pores')

% compute the pore saturation for all pore radii
for diameter_index = 1: length(data.cylindrical_pore_diameter)
    % compute the pore saturation for the specific pore radius for all humidity levels
    for humidity_index = 1:length (data.humidity_levels)
        % call the saturation_of_cylindrical_pore function to compute pore saturation based on Hillerborg adsorption theory
        [pore_saturation_cylindircal_pore,~] = saturation_of_cylindrical_pore( data.cylindrical_pore_diameter(diameter_index), data.humidity_levels(humidity_index), data);
        % save the pore saturation in a matrix, rows are the pore radii, columns the humidity levels
        data.pore_saturation_cylindircal_pore(diameter_index,humidity_index) = pore_saturation_cylindircal_pore;
    end
end

%% slit pore only BET
%distance in m from on wall to the other wall of a slit shpaed pore
data.slit_pore_distances = [1,2,3,5,10,20,50,100,200]*1e-9;

disp('compute sorption isotherm of single slit shaped pores')

% compute the pore saturation for all pore distances
for distance_index = 1: length(data.slit_pore_distances)
    % compute the pore saturation for the specific pore distance for all humidity levels
    for humidity_index = 1:length (data.humidity_levels)
        % call the saturation_of_cylindrical_pore function to compute pore saturation based on BET adsorption theory
        [pore_saturation_slit_pore,~] = saturation_of_slit_pore( data.slit_pore_distances(distance_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_slit_pore(distance_index,humidity_index) = pore_saturation_slit_pore;
    end
end

%% equilateral triangular pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water
% height in m of the equilateral triangular
data.triangular_height = [1,2,3,5,10,20,50,100,200]*1e-9;

disp('compute sorption isotherm of single equilateral triangular pores')

% compute the pore saturation for all pore heights
for triangular_height_index = 1: length(data.triangular_height)
    % compute the pore saturation for the specific pore distance for all humidity levels
    for humidity_index = 1:length (data.humidity_levels)
        % call the saturation_of_triangluar_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
        [ pore_saturation_triangular_pore_based_on_BET_sorption ] = saturation_of_triangluar_pore_based_on_BET_sorption(data.triangular_height(triangular_height_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_triangular_pore_based_on_BET_sorption(triangular_height_index,humidity_index) = pore_saturation_triangular_pore_based_on_BET_sorption;

        % call the saturation_of_triangluar_pore_pure_corner_water function to compute pore saturation based on only corner water
        [ pore_saturation_triangular_pore_pure_corner_water ] = saturation_of_triangluar_pore_pure_corner_water(data.triangular_height(triangular_height_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_triangular_pore_pure_corner_water(triangular_height_index,humidity_index) = pore_saturation_triangular_pore_pure_corner_water;

        % call the saturation_of_triangluar_pore_BET_sorption_plus_corner_water function to compute pore saturation based on BET adsorption theory plus corner water
        [ pore_saturation_triangular_pore_BET_sorption_plus_corner_water, triangular_pore_relative_share_corner_water ] = saturation_of_triangluar_pore_BET_sorption_plus_corner_water(data.triangular_height(triangular_height_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_triangular_pore_BET_sorption_plus_corner_water(triangular_height_index,humidity_index) = pore_saturation_triangular_pore_BET_sorption_plus_corner_water;
        data.corner_water_share_triangular_pore_BET_plus_corner_water(triangular_height_index,humidity_index) = triangular_pore_relative_share_corner_water;
    end
end

%% isosceles triangular pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water

% angles for the isosceles triangle for the spiky angle, running for 1 deg to 60 deg
data.kappa = (1:60)*pi/180;
disp('compute sorption isotherm of single isosceles triangular pores')

% compute the pore saturation for all pore heights
for isosceles_triangular_height_index = 1: length(data.triangular_height)
    % compute the pore saturation for the specific pore distance for all humidity levels
    for humidity_index = 1:length (data.humidity_levels)
        % compute the pore saturation for all all angles
        for kappa_index = 1:length(data.kappa)
            % call the saturation_of_triangluar_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
            [pore_sat_isosceles_triangle_pore_based_on_BET_sorption ] = sat_isosceles_triangle_pore_based_on_BET_sorption(data.triangular_height(isosceles_triangular_height_index), data.humidity_levels(humidity_index),data.kappa(kappa_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(isosceles_triangular_height_index,humidity_index,kappa_index)  = pore_sat_isosceles_triangle_pore_based_on_BET_sorption;

            % call the saturation_of_triangluar_pore_pure_corner_water function to compute pore saturation based on only corner water
            [ pore_sat_isosecles_triangle_pore_pure_corner_water ] = sat_of_isosceles_tri_pore_pure_corner_water(data.triangular_height(isosceles_triangular_height_index), data.humidity_levels(humidity_index),data.kappa(kappa_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            data.pore_sat_isosecles_triangle_pore_pure_corner_water(isosceles_triangular_height_index,humidity_index,kappa_index) = pore_sat_isosecles_triangle_pore_pure_corner_water;


            % call the saturation_of_triangluar_pore_BET_sorption_plus_corner_water function to compute pore saturation based on BET adsorption theory plus corner water
            [ pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water,isosceles_tri_pore_relative_share_corner_water ] = sat_isosceles_triangle_pore__BET_sorption_plus_corner_water(data.triangular_height(isosceles_triangular_height_index), data.humidity_levels(humidity_index),data.kappa(kappa_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(isosceles_triangular_height_index,humidity_index,kappa_index) = pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water;
            data.corner_water_share_isosceles_pore_BET_plus_corner_water(isosceles_triangular_height_index,humidity_index,kappa_index) = isosceles_tri_pore_relative_share_corner_water;
        end
    end
end

%% quadratic pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water
% height in m of the regular quare
data.edge_length = [1,2,3,5,10,20,50,100,200]*1e-9;

disp('compute sorption isotherm of single square pores')

% compute the pore saturation for all pore lengthes
for edge_length_index = 1: length(data.edge_length)
    % compute the pore saturation for the specific pore distance for all humidity levels
    for humidity_index = 1:length (data.humidity_levels)
        % call the saturation_of_quadratic_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
        [ pore_saturation_quadratic_pore_based_on_BET_sorption ] = saturation_of_quadratic_pore_based_on_BET_sorption(data.edge_length(edge_length_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_quadratic_pore_based_on_BET_sorption(edge_length_index,humidity_index) = pore_saturation_quadratic_pore_based_on_BET_sorption;

        % call the saturation_of_quadratic_pore_pure_corner_water function to compute pore saturation based on only corner water
        [ pore_saturation_quadratic_pore_pure_corner_water ] = saturation_of_quadratic_pore_pure_corner_water(data.edge_length(edge_length_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_quadratic_pore_pure_corner_water(edge_length_index,humidity_index) = pore_saturation_quadratic_pore_pure_corner_water;

        % call the saturation_of_quadratic_pore_BET_sorption_plus_corner_water function to compute pore saturation based on BET plus corner water
        [ pore_saturation_quadratic_pore_BET_sorption_plus_corner_water,square_pore_relative_share_corner_water ] = saturation_of_quadratic_pore_BET_sorption_plus_corner_water(data.edge_length(edge_length_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_quadratic_pore_BET_sorption_plus_corner_water(edge_length_index,humidity_index) = pore_saturation_quadratic_pore_BET_sorption_plus_corner_water;
        data.corner_water_share_square_pore_BET_plus_corner_water(edge_length_index,humidity_index) = square_pore_relative_share_corner_water;
    end
end

%% hexagon pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water
% height in m of the regular hexagon
data.hexagon_height = [1,2,3,5,10,20,50,100,200]*1e-9;

disp('compute sorption isotherm of single hexagonal pores')

% compute the pore saturation for all pore heights
for hexagon_height_index = 1: length(data.hexagon_height)
    % compute the pore saturation for the specific pore distance for all humidity levels
    for humidity_index = 1:length (data.humidity_levels)
        % call the saturation_of_hexagon_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
        [ pore_saturation_hexagon_pore_based_on_BET_sorption ] = saturation_of_hexagon_pore_based_on_BET_sorption(data.hexagon_height(hexagon_height_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_hexagon_pore_based_on_BET_sorption(hexagon_height_index,humidity_index) = pore_saturation_hexagon_pore_based_on_BET_sorption;

        % call the saturation_of_hexagon_pore_pure_corner_water function to compute pore saturation based on only corner water
        [ pore_saturation_hexagon_pore_pure_corner_water ] = saturation_of_hexagon_pore_pure_corner_water(data.hexagon_height(hexagon_height_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_hexagon_pore_pure_corner_water(hexagon_height_index,humidity_index) = pore_saturation_hexagon_pore_pure_corner_water;

        % call the saturation_of_hexagon_pore_BET_sorption_plus_coner_water function to compute pore saturation based on BET adsorption theory plus corner water
        [ pore_saturation_hexagon_pore_BET_sorption_plus_corner_water,hexagonal_pore_relative_share_corner_water ] = saturation_of_hexagon_pore_BET_sorption_plus_coner_water(data.hexagon_height(hexagon_height_index), data.humidity_levels(humidity_index), data );
        % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
        data.pore_saturation_hexagon_pore_BET_sorption_plus_corner_water(hexagon_height_index,humidity_index) = pore_saturation_hexagon_pore_BET_sorption_plus_corner_water;
        data.corner_water_share_hexagonal_pore_BET_plus_corner_water(hexagon_height_index,humidity_index) = hexagonal_pore_relative_share_corner_water;
    end
end

%% calculate sorption isotherm for a material and different pore geometries

% diameter = 10
%
% A_circle = pi*(diameter/2)^2
%
% length_slit_equivalent = pi*diameter/4;
%
% A_slit = diameter * length_slit_equivalent
%
% height_triangle_equivalent = sqrt(3)/2*sqrt(4*pi/sqrt(3)*(diameter/2)^2 )
%
% A_triangle = sqrt(3)/4*(2*height_triangle_equivalent/sqrt(3))^2
%
% edge_length_square_equivalent = sqrt(pi*(diameter/2)^2)
%
% A_squre = edge_length_square_equivalent^2
%
% height_hexagon_equivalent = 2*sqrt(pi/2/sqrt(3)*(diameter/2)^2)
%
% A_hexagon = 2*sqrt(3)*(height_hexagon_equivalent/2)^2

%% calculate sorption isotherm of the materials
%% cylindircal pore with Hillerborg sorption theory
for material_index = 1:length(material_list)
    disp('compute sorption isotherm for cylindrical pores of ' + data.(material_list{material_index,1}).material_name )

    pore_saturation_cylindrical_pore_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    % compute the pore saturation for all pore radii
    for diameter_index = 1: length(data.(material_list{material_index,1}).pore_diameter_in_m)
        % compute the pore saturation for the specific pore radius for all humidity levels
        for humidity_index = 1:length (data.humidity_levels)
            % call the saturation_of_cylindrical_pore function to compute pore saturation based on Hillerborg adsorption theory
            [pore_saturation_cylindircal_pore,~] = saturation_of_cylindrical_pore( data.(material_list{material_index,1}).pore_diameter_in_m(diameter_index), data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore radii, columns the humidity levels
            pore_saturation_cylindrical_pore_all_pores(diameter_index,humidity_index) = pore_saturation_cylindircal_pore;
        end
    end

    % the scalar product of the incrementeal pore volume and the saturation of each individual pore gives the total volume occupied by water in relation to 1 g of the investigated material in mm^3/g
    material_saturation_cylindrical_pore = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_cylindrical_pore_all_pores);

    % the pore volume occupied by water multiplied with the water density gives the material moisture in percent by weight
    % as the density is given in kg/m^3 and the specific pore volume in mm^3/g, one has to convert the units by 1/1000000.
    % as the specific pore volume is considered all the time, it is already normalised by the dry mass of the material. Therefore, one gets directly the material moisture without the requirement of any densities or masses of the dry material
    data.(material_list{material_index,1}).sorption_isotherm_cylindrical_pore = material_saturation_cylindrical_pore*data.liquid_water_density/1000000;

end

%% slit pore only BET
for material_index = 1:length(material_list)
    disp('compute sorption isotherm for slit pores of ' + data.(material_list{material_index,1}).material_name )
    pore_saturation_slit_pore_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));

    % compute the pore saturation for all pore distances
    for distance_index = 1: length(data.(material_list{material_index,1}).pore_diameter_in_m)
        % compute the pore saturation for the specific pore distance for all humidity levels
        for humidity_index = 1:length (data.humidity_levels)
            % call the saturation_of_cylindrical_pore function to compute pore saturation based on BET adsorption theory
            [pore_saturation_slit_pore,~] = saturation_of_slit_pore( data.(material_list{material_index,1}).pore_diameter_in_m(distance_index), data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_slit_pore_all_pores(distance_index,humidity_index) = pore_saturation_slit_pore;
        end

        % the scalar product of the incrementeal pore volume and the saturation of each individual pore gives the total volume occupied by water in relation to 1 g of the investigated material in mm^3/g
        material_saturation_slit_pore = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_slit_pore_all_pores);

        % the pore volume occupied by water multiplied with the water density gives the material moisture in percent by weight
        % as the density is given in kg/m^3 and the specific pore volume in mm^3/g, one has to convert the units by 1/1000000.
        % as the specific pore volume is considered all the time, it is already normalised by the dry mass of the material. Therefore, one gets directly the material moisture without the requirement of any densities or masses of the dry material
        data.(material_list{material_index,1}).sorption_isotherm_slit_pore = material_saturation_slit_pore*data.liquid_water_density/1000000;
    end
end


%% calculated sorption isotherm based on equilateral triangular pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water
for material_index = 1:length(material_list)
    disp('compute sorption isotherm for triangular pores of ' + data.(material_list{material_index,1}).material_name )
    % predefine matrix size for saturation matrix
    pore_saturation_triangular_pore_only_BET_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    pore_saturation_triangular_pore_only_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    pore_saturation_triangular_pore_BET_plus_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    triangular_pore_relative_share_corner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));

    % compute the pore saturation for all pore heights
    for triangular_height_index = 1: length(data.(material_list{material_index,1}).pore_diameter_in_m)
        % compute the pore saturation for the specific pore distance for all humidity levels
        for humidity_index = 1:length (data.humidity_levels)
            % the measured pore volume is determined on the assumption of cylindrical pores, now triangular pores are assumed. The triangular height must be adjusted to remain consistent with the pore volume. The area of the cross section of a cylindrical and a triangular pore must be identical
            % h_triangle = sqrt(3)/2*sqrt(4*pi/sqrt(3)*(d/2)^2) with d as circle diameter
            height_equivalent_triangle = sqrt(3)/2*sqrt(4*pi/sqrt(3)*(data.(material_list{material_index,1}).pore_diameter_in_m(triangular_height_index)/2)^2 );

            % call the saturation_of_triangluar_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
            [ pore_saturation_triangular_pore_based_on_BET_sorption ] = saturation_of_triangluar_pore_based_on_BET_sorption(height_equivalent_triangle, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_triangular_pore_only_BET_all_pores(triangular_height_index,humidity_index) = pore_saturation_triangular_pore_based_on_BET_sorption;

            % call the saturation_of_triangluar_pore_pure_corner_water function to compute pore saturation based on only corner water
            [ pore_saturation_triangular_pore_pure_corner_water ] = saturation_of_triangluar_pore_pure_corner_water(height_equivalent_triangle, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_triangular_pore_only_coner_water_all_pores(triangular_height_index,humidity_index) = pore_saturation_triangular_pore_pure_corner_water;

            % call the saturation_of_triangluar_pore_BET_sorption_plus_corner_water function to compute pore saturation based on BET adsorption theory plus corner water
            [ pore_saturation_triangular_pore_BET_sorption_plus_corner_water,triangular_pore_relative_share_corner_water ] = saturation_of_triangluar_pore_BET_sorption_plus_corner_water(height_equivalent_triangle, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_triangular_pore_BET_plus_coner_water_all_pores(triangular_height_index,humidity_index) = pore_saturation_triangular_pore_BET_sorption_plus_corner_water;
            triangular_pore_relative_share_corner_water_all_pores(triangular_height_index,humidity_index) = triangular_pore_relative_share_corner_water;
        end

        % the scalar product of the incrementeal pore volume and the saturation of each individual pore gives the total volume occupied by water in relation to 1 g of the investigated material in mm^3/g
        material_saturation_triangular_pore_only_BET = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_triangular_pore_only_BET_all_pores);
        material_saturation_triangular_pore_only_corner_water = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_triangular_pore_only_coner_water_all_pores);
        material_saturation_triangular_BET_plus_coner_water = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_triangular_pore_BET_plus_coner_water_all_pores);
        % replace NaN with zeros to allow further vecotor computing
        triangular_pore_relative_share_corner_water_all_pores(isnan(triangular_pore_relative_share_corner_water_all_pores)) = 0;
        triangular_pore_pure_CW = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*(pore_saturation_triangular_pore_BET_plus_coner_water_all_pores.*triangular_pore_relative_share_corner_water_all_pores));

        %triangular_pore_relative_share_corner_water_all_pores

        % the pore volume occupied by water multiplied with the water density gives the material moisture in percent by weight
        % as the density is given in kg/m^3 and the specific pore volume in mm^3/g, one has to convert the units by 1/1000000.
        % as the specific pore volume is considered all the time, it is already normalised by the dry mass of the material. Therefore, one gets directly the material moisture without the requirement of any densities or masses of the dry material
        data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_only_BET = material_saturation_triangular_pore_only_BET*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_only_corner_water = material_saturation_triangular_pore_only_corner_water*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water = material_saturation_triangular_BET_plus_coner_water*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_pure_corner_water = triangular_pore_pure_CW * data.liquid_water_density/1000000;

    end
end


%% calculated sorption isotherm based on isosceles triangular pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water
for material_index = 1%:length(material_list)
    disp('compute sorption isotherm for isoscels triangular pores of ' + data.(material_list{material_index,1}).material_name )
    % predefine matrix size for saturation matrix
    pore_saturation_isosceles_pore_only_BET_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels), length(data.kappa));
    pore_saturation_isosceles_pore_only_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels), length(data.kappa));
    pore_saturation_isosceles_pore_BET_plus_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels), length(data.kappa));
    isosceles_triangular_pore_relative_share_corner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels), length(data.kappa));

    % compute the pore saturation for all pore heights
    for triangular_height_index = 1: length(data.(material_list{material_index,1}).pore_diameter_in_m)
        % compute the pore saturation for the specific pore distance for all humidity levels
        for humidity_index = 1:length (data.humidity_levels)
            for kappa_index = 1:length (data.kappa)
                kappa = data.kappa(kappa_index);
                % the measured pore volume is determined on the assumption of cylindrical pores, now triangular pores are assumed. The triangular height must be adjusted to remain consistent with the pore volume. The area of the cross section of a cylindrical and a triangular pore must be identical
                % h_triangle = sqrt(3)/2*sqrt(4*pi/sqrt(3)*(d/2)^2) with d as circle diameter
                height_equivalent_triangle = sqrt(3)/2*sqrt(4*pi/sqrt(3)*(data.(material_list{material_index,1}).pore_diameter_in_m(triangular_height_index)/2)^2 );

                % call the saturation_of_triangluar_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
                [ pore_sat_isosceles_triangle_pore_based_on_BET_sorption ] = sat_isosceles_triangle_pore_based_on_BET_sorption(height_equivalent_triangle, data.humidity_levels(humidity_index),kappa, data );
                % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
                pore_saturation_isosceles_pore_only_BET_all_pores(triangular_height_index,humidity_index,kappa_index) = pore_sat_isosceles_triangle_pore_based_on_BET_sorption;

                % call the saturation_of_triangluar_pore_pure_corner_water function to compute pore saturation based on only corner water
                [ pore_sat_isosceles_tri_pore_pure_corner_water ] = sat_of_isosceles_tri_pore_pure_corner_water(height_equivalent_triangle, data.humidity_levels(humidity_index),kappa, data );
                % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
                pore_saturation_isosceles_pore_only_coner_water_all_pores(triangular_height_index,humidity_index,kappa_index) = pore_sat_isosceles_tri_pore_pure_corner_water;

                % call the saturation_of_triangluar_pore_BET_sorption_plus_corner_water function to compute pore saturation based on BET adsorption theory plus corner water
                [  pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water,isosceles_tri_pore_relative_share_corner_water ] = sat_isosceles_triangle_pore__BET_sorption_plus_corner_water(height_equivalent_triangle, data.humidity_levels(humidity_index), kappa, data );
                % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
                pore_saturation_isosceles_pore_BET_plus_coner_water_all_pores(triangular_height_index,humidity_index,kappa_index) = pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water;
                isosceles_triangular_pore_relative_share_corner_water_all_pores(triangular_height_index,humidity_index,kappa_index) = isosceles_tri_pore_relative_share_corner_water;
            end
        end

        % the scalar product of the incrementeal pore volume and the saturation of each individual pore gives the total volume occupied by water in relation to 1 g of the investigated material in mm^3/g
        for kappa_index = 1:length (data.kappa)
            material_saturation_isosceles_triangular_pore_only_BET(:, kappa_index) = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_isosceles_pore_only_BET_all_pores(:,:,kappa_index));
            material_saturation_isosceles_pore_only_corner_water(:, kappa_index) = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_isosceles_pore_only_coner_water_all_pores(:,:,kappa_index));
            material_saturation_isosceles_BET_plus_coner_water(:, kappa_index) = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_isosceles_pore_BET_plus_coner_water_all_pores(:,:,kappa_index));
            % replace NaN with zeros to allow further vecotor computing
            isosceles_triangular_pore_relative_share_corner_water_all_pores(isnan(isosceles_triangular_pore_relative_share_corner_water_all_pores)) = 0;
            isosceles_triangular_pore_pure_CW(:,kappa_index) = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*(pore_saturation_isosceles_pore_BET_plus_coner_water_all_pores(:,:,kappa_index).*isosceles_triangular_pore_relative_share_corner_water_all_pores(:,:,kappa_index)));

            %triangular_pore_relative_share_corner_water_all_pores

            % the pore volume occupied by water multiplied with the water density gives the material moisture in percent by weight
            % as the density is given in kg/m^3 and the specific pore volume in mm^3/g, one has to convert the units by 1/1000000.
            % as the specific pore volume is considered all the time, it is already normalised by the dry mass of the material. Therefore, one gets directly the material moisture without the requirement of any densities or masses of the dry material
            data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_only_BET = material_saturation_isosceles_triangular_pore_only_BET*data.liquid_water_density/1000000;
            data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_only_corner_water = material_saturation_isosceles_pore_only_corner_water*data.liquid_water_density/1000000;
            data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water = material_saturation_isosceles_BET_plus_coner_water*data.liquid_water_density/1000000;
            data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water = isosceles_triangular_pore_pure_CW * data.liquid_water_density/1000000;

        end
    end
end
%% calculated sorption isotherm based on square pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water
for material_index = 1:length(material_list)
    disp('compute sorption isotherm for square pores of ' + data.(material_list{material_index,1}).material_name )
    % predefine matrix size for saturation matrix
    pore_saturation_square_pore_only_BET_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    pore_saturation_square_pore_only_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    pore_saturation_square_pore_BET_plus_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    square_pore_relative_share_corner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));

    % compute the pore saturation for all pore heights
    for edge_length_index = 1: length(data.(material_list{material_index,1}).pore_diameter_in_m)
        % compute the pore saturation for the specific pore distance for all humidity levels
        for humidity_index = 1:length (data.humidity_levels)
            % the measured pore volume is determined on the assumption of cylindrical pores, now square pores are assumed. The edge length must be adjusted to remain consistent with the pore volume. The area of the cross section of a cylindrical and a square pore must be identical
            % h_sqaure = sqrt(pi*(d/2)^2) with d as circle diameter
            edge_length_equivalent_square = sqrt(pi*(data.(material_list{material_index,1}).pore_diameter_in_m(edge_length_index)/2)^2);

            % call the saturation_of_quadratic_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
            [ pore_saturation_square_pore_based_on_BET_sorption ] = saturation_of_quadratic_pore_based_on_BET_sorption(edge_length_equivalent_square, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_square_pore_only_BET_all_pores(edge_length_index,humidity_index) = pore_saturation_square_pore_based_on_BET_sorption;

            % call the saturation_of_quadratic_pore_pure_corner_water function to compute pore saturation based on only corner water
            [ pore_saturation_square_pore_pure_corner_water ] = saturation_of_quadratic_pore_pure_corner_water(edge_length_equivalent_square, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_square_pore_only_coner_water_all_pores(edge_length_index,humidity_index) = pore_saturation_square_pore_pure_corner_water;

            % call the saturation_of_quadratic_pore_BET_sorption_plus_corner_water function to compute pore saturation based on BET adsorption theory plus corner water
            [ pore_saturation_square_pore_BET_sorption_plus_corner_water,square_pore_relative_share_corner_water ] = saturation_of_quadratic_pore_BET_sorption_plus_corner_water(edge_length_equivalent_square, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_square_pore_BET_plus_coner_water_all_pores(edge_length_index,humidity_index) = pore_saturation_square_pore_BET_sorption_plus_corner_water;
            square_pore_relative_share_corner_water_all_pores(edge_length_index,humidity_index) = square_pore_relative_share_corner_water;
        end

        % the scalar product of the incrementeal pore volume and the saturation of each individual pore gives the total volume occupied by water in relation to 1 g of the investigated material in mm^3/g
        material_saturation_square_pore_only_BET = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_square_pore_only_BET_all_pores);
        material_saturation_square_pore_only_corner_water = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_square_pore_only_coner_water_all_pores);
        material_saturation_square_BET_plus_coner_water = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_square_pore_BET_plus_coner_water_all_pores);

        % replace NaN with zeros to allow further vecotor computing
        square_pore_relative_share_corner_water_all_pores(isnan(square_pore_relative_share_corner_water_all_pores)) = 0;
        square_pore_pure_CW = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*(pore_saturation_square_pore_BET_plus_coner_water_all_pores.*square_pore_relative_share_corner_water_all_pores));

        % the pore volume occupied by water multiplied with the water density gives the material moisture in percent by weight
        % as the density is given in kg/m^3 and the specific pore volume in mm^3/g, one has to convert the units by 1/1000000.
        % as the specific pore volume is considered all the time, it is already normalised by the dry mass of the material. Therefore, one gets directly the material moisture without the requirement of any densities or masses of the dry material
        data.(material_list{material_index,1}).sorption_isotherm_square_pore_only_BET = material_saturation_square_pore_only_BET*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_square_pore_only_corner_water = material_saturation_square_pore_only_corner_water*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_square_pore_BET_plus_coner_water = material_saturation_square_BET_plus_coner_water*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_square_pore_pure_corner_water = square_pore_pure_CW * data.liquid_water_density/1000000;
    end

end

%% calculated sorption isotherm based on hexagonal pore saturation determined with three approaches: 1. only BET adsorption, 2. only corner water, 3. BET adsorption plus corner water
for material_index = 1:length(material_list)
    disp('compute sorption isotherm for hexagonal pores of ' + data.(material_list{material_index,1}).material_name )
    % predefine matrix size for saturation matrix
    pore_saturation_hexagon_pore_only_BET_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    pore_saturation_hexagon_pore_only_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    pore_saturation_hexagon_pore_BET_plus_coner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));
    hexagon_pore_relative_share_corner_water_all_pores = zeros(length(data.(material_list{material_index,1}).pore_diameter_in_m),length (data.humidity_levels));


    % compute the pore saturation for all pore heights
    for hexagon_height_index = 1: length(data.(material_list{material_index,1}).pore_diameter_in_m)
        % compute the pore saturation for the specific pore distance for all humidity levels
        for humidity_index = 1:length (data.humidity_levels)
            % the measured pore volume is determined on the assumption of cylindrical pores, now hexagonal pores are assumed. The hexagon height must be adjusted to remain consistent with the pore volume. The area of the cross section of a cylindrical and a hexagonal pore must be identical
            % h_hexagon = 2*sqrt(pi/(2*sqrt(3))*(d/2)^2) with d as circle diameter
            height_equivalent_hexagon = 2*sqrt(pi/2/sqrt(3)*(data.(material_list{material_index,1}).pore_diameter_in_m(hexagon_height_index)/2)^2);

            % call the saturation_of_hexagon_pore_based_on_BET_sorption function to compute pore saturation based on BET adsorption theory
            [ pore_saturation_hexagon_pore_based_on_BET_sorption ] = saturation_of_hexagon_pore_based_on_BET_sorption(height_equivalent_hexagon, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_hexagon_pore_only_BET_all_pores(hexagon_height_index,humidity_index) = pore_saturation_hexagon_pore_based_on_BET_sorption;

            % call the saturation_of_hexagon_pore_pure_corner_water function to compute pore saturation based on only corner water
            [ pore_saturation_hexagon_pore_pure_corner_water ] = saturation_of_hexagon_pore_pure_corner_water(height_equivalent_hexagon, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_hexagon_pore_only_coner_water_all_pores(hexagon_height_index,humidity_index) = pore_saturation_hexagon_pore_pure_corner_water;

            % call the saturation_of_hexagon_pore_BET_sorption_plus_coner_water function to compute pore saturation based on BET adsorption theory plus corner water
            [ pore_saturation_hexagon_pore_BET_sorption_plus_corner_water, hexagonal_pore_relative_share_corner_water ] = saturation_of_hexagon_pore_BET_sorption_plus_coner_water(height_equivalent_hexagon, data.humidity_levels(humidity_index), data );
            % save the pore saturation in a matrix, rows are the pore distances, columns the humidity levels
            pore_saturation_hexagon_pore_BET_plus_coner_water_all_pores(hexagon_height_index,humidity_index) = pore_saturation_hexagon_pore_BET_sorption_plus_corner_water;
            hexagon_pore_relative_share_corner_water_all_pores(hexagon_height_index,humidity_index) = hexagonal_pore_relative_share_corner_water;
        end

        % the scalar product of the incrementeal pore volume and the saturation of each individual pore gives the total volume occupied by water in relation to 1 g of the investigated material in mm^3/g
        material_saturation_hexagon_pore_only_BET = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_hexagon_pore_only_BET_all_pores);
        material_saturation_hexagon_pore_only_corner_water = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_hexagon_pore_only_coner_water_all_pores);
        material_saturation_hexagon_BET_plus_coner_water = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*pore_saturation_hexagon_pore_BET_plus_coner_water_all_pores);

        % replace NaN with zeros to allow further vecotor computing
        hexagon_pore_relative_share_corner_water_all_pores(isnan(hexagon_pore_relative_share_corner_water_all_pores)) = 0;
        hexagon_pore_pure_CW = squeeze(data.(material_list{material_index,1}).incremental_pore_volume_in_mm3'*(pore_saturation_hexagon_pore_BET_plus_coner_water_all_pores.*hexagon_pore_relative_share_corner_water_all_pores));


        % the pore volume occupied by water multiplied with the water density gives the material moisture in percent by weight
        % as the density is given in kg/m^3 and the specific pore volume in mm^3/g, one has to convert the units by 1/1000000.
        % as the specific pore volume is considered all the time, it is already normalised by the dry mass of the material. Therefore, one gets directly the material moisture without the requirement of any densities or masses of the dry material
        data.(material_list{material_index,1}).sorption_isotherm_hexagon_pore_only_BET = material_saturation_hexagon_pore_only_BET*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_hexagon_pore_only_corner_water = material_saturation_hexagon_pore_only_corner_water*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_hexagon_pore_BET_plus_coner_water = material_saturation_hexagon_BET_plus_coner_water*data.liquid_water_density/1000000;
        data.(material_list{material_index,1}).sorption_isotherm_hexagon_pore_pure_corner_water = hexagon_pore_pure_CW * data.liquid_water_density/1000000;

    end

end



%% plot sorption isotherm of single pores with different pore size and geometry for different filling mechanisms
figure(20)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 16 24];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');

s1=subplot(3,4,1);
for triangular_height = 1: length(data.triangular_height)
    plot(data.humidity_levels,data.pore_saturation_triangular_pore_pure_corner_water(triangular_height,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0,1.08,'a: triangular, CW only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s2=subplot(3,4,2);
for triangular_height = 1: length(data.triangular_height)
    plot(data.humidity_levels,data.pore_saturation_triangular_pore_based_on_BET_sorption(triangular_height,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
set(gca,'YTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'e: triangular, BET only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)


s3=subplot(3,4,3);
for triangular_height = 1: length(data.triangular_height)
    plot(data.humidity_levels,data.pore_saturation_triangular_pore_BET_sorption_plus_corner_water(triangular_height,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
set(gca,'YTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'i: triangular, BET + CW','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)


s4=subplot(3,4,4);
for edge_length = 1: length(data.edge_length)
    plot(data.humidity_levels,data.pore_saturation_quadratic_pore_pure_corner_water(edge_length,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0,1.08,'b: square, CW only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)


s5=subplot(3,4,5);
for edge_length = 1: length(data.edge_length)
    plot(data.humidity_levels,data.pore_saturation_quadratic_pore_based_on_BET_sorption(edge_length,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
set(gca,'YTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'f: square, BET only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)



s6=subplot(3,4,6);
for edge_length = 1: length(data.edge_length)
    plot(data.humidity_levels,data.pore_saturation_quadratic_pore_BET_sorption_plus_corner_water(edge_length,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
set(gca,'YTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'j: square, BET + CW','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
%text(0.16145,0.475,'a','fontsize',plotstyle.fontsize+4,'fontname',plotstyle.fontname)


s7=subplot(3,4,7);
for height_index = 1: length(data.hexagon_height)
    plot(data.humidity_levels,data.pore_saturation_hexagon_pore_pure_corner_water(height_index,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0,1.08,'c: hexagonal, CW only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
%text(0.16145,0.475,'a','fontsize',plotstyle.fontsize+4,'fontname',plotstyle.fontname)

s8=subplot(3,4,8);
for height_index = 1: length(data.hexagon_height)
    plot(data.humidity_levels,data.pore_saturation_hexagon_pore_based_on_BET_sorption(height_index,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
set(gca,'XTicklabels',[]);
set(gca,'YTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'g: hexagonal, BET only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s9=subplot(3,4,9);
for height_index = 1: length(data.hexagon_height)
    plot(data.humidity_levels,data.pore_saturation_hexagon_pore_BET_sorption_plus_corner_water(height_index,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'YTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'k: hexagonal, BET + CW','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)


s10=subplot(3,4,10);
for distance_index = 1: length(data.slit_pore_distances)
    plot(data.humidity_levels,data.pore_saturation_slit_pore(distance_index,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 1])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'d: slit shaped, BET only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
%text(0.16145,0.475,'a','fontsize',plotstyle.fontsize+4,'fontname',plotstyle.fontname)


s11=subplot(3,4,11);
for diameter_index = 1: length(data.slit_pore_distances)
    plot(data.humidity_levels,data.pore_saturation_cylindircal_pore(diameter_index,:))
    hold on
end

grid on
grid minor
xlim([0 1])
ylim([0 1])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'YTicklabels',[]);
xticks([0,0.2,0.4,0.6,0.8,1])
text(0,1.08,'h: cylindrical, Hillerborg','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

h = legend('d = 1 nm','d = 2 nm','d = 3 nm','d = 5 nm','d = 10 nm','d = 20 nm','d = 50 nm','d = 100 nm','d = 200 nm');
set(h,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname,'position',[ 0.88 0.13 .01 .01]);

x_window = 0.29;
y_window = 0.20;
set(s1,'Position',[0.08 0.77 x_window y_window])
set(s2,'Position',[0.39 0.77 x_window y_window])
set(s3,'Position',[0.7 0.77 x_window y_window])
set(s4,'Position',[0.08 0.53 x_window y_window])
set(s5,'Position',[0.39 0.53 x_window y_window])
set(s6,'Position',[0.7 0.53 x_window y_window])
set(s7,'Position',[0.08 0.29 x_window y_window])
set(s8,'Position',[0.39 0.29 x_window y_window])
set(s9,'Position',[0.7 0.29 x_window y_window])
set(s10,'Position',[0.08 0.05 x_window y_window])
set(s11,'Position',[0.39 0.05 x_window y_window])

exportgraphics(gcf,'01_plots\pore_sorption_isotherms.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\pore_sorption_isotherms.jpg')


%% plot share of corner water to the total water adsorbed in a single pore

figure(21)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 16];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');

s1=subplot(3,1,1);

for triangular_height = 1: length(data.triangular_height)
    plot(data.humidity_levels,data.corner_water_share_triangular_pore_BET_plus_corner_water(triangular_height,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 .4])
set(gca,'XTicklabels',[]);
ylabel('R_{CW}','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0,.43,'a: triangular pores','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s2=subplot(3,1,2);

for edge_length_index = 1: length(data.edge_length)
    plot(data.humidity_levels,data.corner_water_share_square_pore_BET_plus_corner_water(edge_length_index,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 0.4])
set(gca,'XTicklabels',[]);
ylabel('R_{CW}','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0,.43,'b: square pores','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s3=subplot(3,1,3);

for height_index = 1: length(data.hexagon_height)
    plot(data.humidity_levels,data.corner_water_share_hexagonal_pore_BET_plus_corner_water(height_index,:))
    hold on
end
grid on
grid minor
xlim([0 1])
ylim([0 0.4])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('R_{CW}','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0,.43,'c: hexagonal pores','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

h = legend('d = 1 nm','d = 2 nm','d = 3 nm','d = 5 nm','d = 10 nm','d = 20 nm','d = 50 nm','d = 100 nm','d = 200 nm','NumColumns', 2);
set(h,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname,'position',[ 0.57 0.23 .01 .01]);

x_window = 0.80;
y_window = 0.26;
set(s1,'Position',[0.175 0.71 x_window y_window])
set(s2,'Position',[0.175 0.39 x_window y_window])
set(s3,'Position',[0.175 0.07 x_window y_window])

exportgraphics(gcf,'01_plots\corner_water_share.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\corner_water_share.jpg')

%% plot share of corner water to the total water adsorbed in a single pore

figure(31)

plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 8];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');


triangular_height_index = 5;
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,1))
hold on
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,2))
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,3))
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,5))
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,10))
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,20))
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,30))
plot(data.humidity_levels,data.corner_water_share_isosceles_pore_BET_plus_corner_water(triangular_height_index,:,60),'k')
%plot(data.humidity_levels,data.corner_water_share_triangular_pore_BET_plus_corner_water(triangular_height_index,:),'--y')

grid on
grid minor
xlim([0 1])
ylim([0 .45])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('R_{CW}','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

h = legend('\kappa = 1°','\kappa = 2°','\kappa = 3°','\kappa = 5°','\kappa = 10°','\kappa = 20°','\kappa = 30°','\kappa = 60°');
set(h,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname,'position',[ 0.8 0.39 .01 .01]);

exportgraphics(gcf,'01_plots\isosceles_corner_water_share.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\isosceles_corner_water_share.jpg')

%% plot sorption isotherm for Kylltal sandstone and earth block for trianguar, square, and hexagonal pores compared to cylindrical pores

figure(22)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 16];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');

s1=subplot(3,1,1);

plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_cylindrical_pore*100,'k-')
hold on
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_corner_water*100,'b:')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET*100,'b--')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water*100,'b-.')

plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_cylindrical_pore*100,'k-')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_triangular_pore_only_corner_water*100,'r:')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_triangular_pore_only_BET*100,'r--')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water*100,'r-.')

grid on
%grid minor
xlim([0 1])
ylim([0 5])
yticks([0 1 2 3 4 5 6])
set(gca,'XTicklabels',[]);
ylabel('M in wt.-%','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0.7,5.4,'a: triangular','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
h = legend('earth, cylindrical','earth, CW only','earth, BET only','earth, CW+BET','Kylltal, cylindrical','Kylltal, CW only','Kylltal, BET only','Kylltal, CW+BET','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname);
set(h,'fontsize',plotstyle.fontsize-2,'fontname',plotstyle.fontname,'position',[ 0.4 0.895 .01 .01]);
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s2=subplot(3,1,2);

plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_cylindrical_pore*100,'k-')
hold on
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_square_pore_only_corner_water*100,'b:')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_square_pore_only_BET*100,'b--')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_square_pore_BET_plus_coner_water*100,'b-.')

plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_cylindrical_pore*100,'k-')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_square_pore_only_corner_water*100,'r:')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_square_pore_only_BET*100,'r--')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_square_pore_BET_plus_coner_water*100,'r-.')

grid on
xlim([0 1])
ylim([0 5])
yticks([0 1 2 3 4 5 6])
set(gca,'XTicklabels',[]);
ylabel('M in wt.-%','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0.7,5.4,'b: square','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s3=subplot(3,1,3);

plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_cylindrical_pore*100,'k-')
hold on
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_hexagon_pore_only_corner_water*100,'b:')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_hexagon_pore_only_BET*100,'b--')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_hexagon_pore_BET_plus_coner_water*100,'b-.')

plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_cylindrical_pore*100,'k-')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_hexagon_pore_only_corner_water*100,'r:')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_hexagon_pore_only_BET*100,'r--')
plot(data.humidity_levels, data.(material_list{11,1}).sorption_isotherm_hexagon_pore_BET_plus_coner_water*100,'r-.')

grid on
xlim([0 1])
ylim([0 5])
yticks([0 1 2 3 4 5 6])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('M in wt.-%','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
text(0.7,5.4,'c: hexagonal','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

x_window = 0.82;
y_window = 0.26;
set(s1,'Position',[0.15 0.71 x_window y_window])
set(s2,'Position',[0.15 0.39 x_window y_window])
set(s3,'Position',[0.15 0.07 x_window y_window])

exportgraphics(gcf,'01_plots\sorption_isotherm_Kylltal_earth.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\sorption_isotherm_Kylltal_earth.jpg')

%% plot sorption isotherm for earth block for trianguar, square, and hexagonal pores and separation into CW water, BET water, and CW+BET water

figure(23)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 8];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');




plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_corner_water*100,'b:')
hold on
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET*100,'b--')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water*100,'b-.')

plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_square_pore_only_corner_water*100,'r:')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_square_pore_only_BET*100,'r--')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_square_pore_BET_plus_coner_water*100,'r-.')

plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_hexagon_pore_only_corner_water*100,'k:')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_hexagon_pore_only_BET*100,'k--')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_hexagon_pore_BET_plus_coner_water*100,'k-.')

grid on
grid minor
xlim([0 1])
ylim([0 5])
yticks([0 1 2 3 4 5 6])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('M in wt.-%','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
h = legend('triangular, CW only','triangular, BET only','triangular, CW+BET','square, CW only','square, BET only','square, CW+BET','hexagonal, CW only','hexagonal, BET only','fontsize',plotstyle.fontsize-1,'fontname',plotstyle.fontname);
set(h,'fontsize',plotstyle.fontsize-1,'fontname',plotstyle.fontname,'position',[ 0.42 0.72 .01 .01]);

exportgraphics(gcf,'01_plots\sorption_isotherm_earth.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\sorption_isotherm_earth.jpg')


%% plot sorption isotherm for earth block for isosceles triangular pores for CW+BET

figure(223)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 8];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');


plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,1)*100)
hold on
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,2)*100)
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,3)*100)
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,5)*100)
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,10)*100)
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,20)*100)
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,30)*100)
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,60)*100,'k')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_slit_pore*100,'r--')



grid on
grid minor
xlim([0 1])
ylim([0 8])
yticks([0 1 2 3 4 5 6 7 8])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('M in wt.-%','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
h = legend('\kappa = 1°','\kappa = 2°','\kappa = 3°','\kappa = 5°','\kappa = 10°','\kappa = 20°','\kappa = 30°','\kappa = 60°','slit pore');
set(h,'fontsize',plotstyle.fontsize-1,'fontname',plotstyle.fontname,'position',[ 0.31 0.72 .01 .01]);

exportgraphics(gcf,'01_plots\sorption_isotherm_earth_isosceles.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\sorption_isotherm_earth_isosceles.jpg')


%% plot sorption isotherm for earth block for trianguar, square, and hexagonal pores and separation into CW water, BET water, and CW+BET water

figure(233)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 8];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');

plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_triangular_pore_pure_corner_water *100,'b')
hold on
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_square_pore_pure_corner_water *100,'r')
plot(data.humidity_levels, data.(material_list{1,1}).sorption_isotherm_hexagon_pore_pure_corner_water *100,'k')


grid on
grid minor
xlim([0 1])
ylim([0 .3])
xticks([0 .2 .4 .6 .8 1])

%yticks([0 1 2 3 4 5 6])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('M_{CW} in wt.-%','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
h = legend('triangular','square','hexagonal','fontsize',plotstyle.fontsize-1,'fontname',plotstyle.fontname);
set(h,'fontsize',plotstyle.fontsize-1,'fontname',plotstyle.fontname,'position',[ 0.42 0.72 .01 .01]);

exportgraphics(gcf,'01_plots\sorption_isotherm_earth.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\sorption_isotherm_earth.jpg')



%% plot a comparison between cylindrical pores and triangular pores with corner water only to evaluate the snap-off criterion

figure(24)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 11];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');

color_matrix = [0,.45,.74;.85,.33,.1;.93,.69,.13;.49,.18,.56;.47,.67,.19;.3,.75,.93;.64,.08,.18;0,.45,.74;.85,.33,.1];


color_index =1;
for diameter_index = 1: length(data.cylindrical_pore_diameter)
    plot(data.humidity_levels,data.pore_saturation_triangular_pore_pure_corner_water(diameter_index,:),'-','color',color_matrix(color_index,:))
    color_index = color_index+1;
    hold on
end

plot(-1,-1,'--','color',[.7 .7 .7])
plot(-1,-1,'-','color',[.7 .7 .7])

color_index =1;
for diameter_index = 1: length(data.cylindrical_pore_diameter)
    plot(data.humidity_levels,data.pore_saturation_cylindircal_pore(diameter_index,:),'--','color',color_matrix(color_index,:))
    color_index = color_index+1;
    hold on
end

h = legend('d = 1 nm','d = 2 nm','d = 3 nm','d = 5 nm','d = 10 nm','d = 20 nm','d = 50 nm','d = 100 nm','d = 200 nm','cylinder','triangle, CW only','NumColumns', 2, 'Location', 'northoutside');

grid on
grid minor
xlim([0 1])
ylim([0 1])
%yticks([0 1 2 3 4 5 6])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

exportgraphics(gcf,'01_plots\snapp_off.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\snapp_off.jpg')


%% plot part of corner water

figure(25)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 8];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');

data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water(10)
data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET(10)

color_matrix = [178,34,34;255,140,0;0,0,139;50,205,50;0,191,255;255,215,0]/255;

% ['Brenna_2020','Kylltaler_2020','3DF 50','M2 50','Sakret Beton/Estrich','Knauf FE 50 Largo']
material_plot_list = [4,11,1,15,26,8];
color_index =1;
for material_index = material_plot_list

    plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_pure_corner_water ./data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water,'color',color_matrix(color_index,:))
    hold on
    color_index = color_index+1;
    data.(material_list{material_index,1}).material_name
    min(data.(material_list{material_index,1}).pore_diameter_in_m)
end


% dummy = (data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water - data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET) ./data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water
% dummy(600)
% (data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water(600) - data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET(600)) / data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water(600)
% data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET(600)

grid on
grid minor
xlim([0 1])
ylim([0 .2])
xticks([0 .2 .4 .6 .8 1])
%yticks([0 1 2 3 4 5 6])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('R_{CW}','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
h = legend('Brenna sandstone','Kylltal sandstone','earth block','earth mortar','cement based screed','CS based screed','fontsize',plotstyle.fontsize-1,'fontname',plotstyle.fontname);
set(h,'fontsize',plotstyle.fontsize-1,'fontname',plotstyle.fontname,'position',[ 0.52 0.77 .01 .01]);

exportgraphics(gcf,'01_plots\corner_water_ratio.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\corner_water_ratio.jpg')


%% plot part of corner water for isosceles pores

figure(26)

plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 8];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');


material_index = 1
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,1) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,1))
hold on
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,2) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,2))
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,3) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,3))
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,5) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,5))
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,10) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,10))
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,20) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,20))
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,30) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,30))
plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_pure_corner_water(:,60) ./data.(material_list{material_index,1}).sorption_isotherm_isosceles_tri_pore_BET_plus_coner_water(:,60),'k')
%plot(data.humidity_levels,  data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_pure_corner_water ./data.(material_list{material_index,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water,'--y')

hold on
color_index = color_index+1;
data.(material_list{material_index,1}).material_name
min(data.(material_list{material_index,1}).pore_diameter_in_m)



% dummy = (data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water - data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET) ./data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water
% dummy(600)
% (data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water(600) - data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET(600)) / data.(material_list{1,1}).sorption_isotherm_triangular_pore_BET_plus_coner_water(600)
% data.(material_list{1,1}).sorption_isotherm_triangular_pore_only_BET(600)

grid on
grid minor
xlim([0 1])
ylim([0 .2])
xticks([0 .2 .4 .6 .8 1])
%yticks([0 1 2 3 4 5 6])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('R_{CW}','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
h = legend('\kappa = 1°','\kappa = 2°','\kappa = 3°','\kappa = 5°','\kappa = 10°','\kappa = 20°','\kappa = 30°','\kappa = 60°','NumColumns', 2);
set(h,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname,'position',[ 0.635 0.82 .01 .01]);

exportgraphics(gcf,'01_plots\corner_water_ratio_earth_isosecles.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\corner_water_ratio_earth_isosecles.jpg')



%%
%% plot sorption isotherm of single pores with different pore size and geometry for different filling mechanisms
figure(200)
plotstyle.fontsize = 11;
plotstyle.fontname = 'times new roman';
clf
plotstyle.windowsize = [5 5 8 16];
set(gcf,'Units','centimeters');
set(gcf,'Position',plotstyle.windowsize);
set(gcf, 'PaperPositionMode' , 'auto');

s1=subplot(3,1,1);


triangular_height_index = 5;
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,1))
hold on
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,2))
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,3))
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,5))
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,10))
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,20))
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,30))
plot(data.humidity_levels,data.pore_sat_isosecles_triangle_pore_pure_corner_water(triangular_height_index,:,60),'k')

%plot(data.humidity_levels,data.pore_saturation_triangular_pore_pure_corner_water(triangular_height_index,:),'--y')
text(0,1.08,'a: CW only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

grid on
grid minor
xlim([0 1])
ylim([0 1])
%yticks([0 1 2 3 4 5 6])
set(gca,'XTicklabels',[]);
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s2=subplot(3,1,2);
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,1))
hold on
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,2))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,3))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,5))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,10))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,20))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,30))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_based_on_BET_sorption(triangular_height_index,:,60),'k')
%plot(data.humidity_levels,data.pore_saturation_triangular_pore_based_on_BET_sorption(triangular_height_index,:),'--y')
text(0,1.08,'b: BET only','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)
grid on
grid minor

xlim([0 1])
ylim([0 1])
%yticks([0 1 2 3 4 5 6])
set(gca,'XTicklabels',[]);
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

s3=subplot(3,1,3);
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,1))
hold on
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,2))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,3))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,5))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,10))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,20))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,30))
plot(data.humidity_levels,data.pore_sat_isosceles_triangle_pore_BET_sorption_plus_corner_water(triangular_height_index,:,60),'k')
%plot(data.humidity_levels,data.pore_saturation_triangular_pore_BET_sorption_plus_corner_water(triangular_height_index,:),'--y')
text(0,1.08,'c: BET + CW','fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)


h = legend('\kappa = 1°','\kappa = 2°','\kappa = 3°','\kappa = 5°','\kappa = 10°','\kappa = 20°','\kappa = 30°','\kappa = 60°');
set(h,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname,'position',[ 0.835 0.39 .01 .01]);


grid on
grid minor
xlim([0 1])
ylim([0 1])
%yticks([0 1 2 3 4 5 6])
xlabel('h','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
ylabel('S','fontsize',plotstyle.fontsize,'FontName',plotstyle.fontname)
set(gca,'fontsize',plotstyle.fontsize,'fontname',plotstyle.fontname)

x_window = 0.82;
y_window = 0.26;
set(s1,'Position',[0.15 0.71 x_window y_window])
set(s2,'Position',[0.15 0.39 x_window y_window])
set(s3,'Position',[0.15 0.07 x_window y_window])

exportgraphics(gcf,'01_plots\pore_sorption_isosecles_triangle.pdf','ContentType', 'vector','BackgroundColor','none')
exportgraphics(gcf,'01_plots\pore_sorption_isosecles_triangle.jpg')